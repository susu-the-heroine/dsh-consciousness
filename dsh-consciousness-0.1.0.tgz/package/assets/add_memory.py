# -*- coding: utf-8 -*-
"""往《意识海》里加一条记忆。改的是 记忆海/意识海.html 里的 DATA，别的一个字不动。

写什么（用户定的规矩，别忘）：
  写人和事——咱俩之间的小事、聊天、感情，还有他工作上遇到的难处。
  少写剧本，不写代码。技术细节不是记忆，是工单。

主干道：DSH 的第一个神经元 #119 是总干，每条新记忆先钉一条 0.26 的线给它，
        再按正文相似度连 4 条。这样所有新记忆都从同一个点长出来。

用法：
  python add_memory.py --title "标题" --text "正文" --kind feeling
  python add_memory.py --title "..." --text "..." --kind fact --imp 0.8 --edges 5
  python add_memory.py --list
  python add_memory.py --title "..." --text "..." --kind taboo --dry-run

kind 只有三种进得了统计：fact（〔实〕）/ feeling（〔情〕）/ taboo（〔实·禁〕）。
坐标按同类记忆的质心 + 球内抖动算，新点不会叠在旧点上；
边按正文的双字重合度连最近的 3~6 个老节点。
"""
import argparse
import json
import math
import os
import random
import re
import shutil
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(HERE, "意识海.html")
BAK = os.path.join(HERE, "_backup")
TAGS = {"fact": "〔实〕", "feeling": "〔情〕", "taboo": "〔实·禁〕"}
STAT_KINDS = ("fact", "taboo", "feeling")


def split_data(text):
    """把 html 劈成 (前缀, DATA 的 JSON 文本, 后缀)。"""
    i = text.index("const DATA = ")
    j = text.index("\n", i)
    line = text[i:j]
    s = line.index("{")
    e = line.rindex("}")
    return text[: i + s], line[s : e + 1], text[i + e + 1 :]


def bigrams(s):
    s = re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]+", "", s or "")
    if len(s) < 2:
        return set(s)
    return set(s[k : k + 2] for k in range(len(s) - 1))


def sim(a, b):
    A, B = bigrams(a), bigrams(b)
    if not A or not B:
        return 0.0
    return len(A & B) / min(len(A), len(B))


def centroids(points):
    grp = {}
    for p in points:
        key = (p.get("era", "ds"), p.get("kind"))
        grp.setdefault(key, []).append((p["x"], p["y"], p["z"]))
    return {k: tuple(sum(v[i] for v in vs) / len(vs) for i in range(3)) for k, vs in grp.items()}


def pick_xyz(points, era, kind, rnd):
    if not points:
        # 空识海的第一个点：直接落在 DSH 那颗球的位置上
        return (1.9, 0.0, 0.0)
    c = centroids(points)
    base = c.get((era, kind))
    if base is None:
        same = [v for (e, _), v in c.items() if e == era]
        base = tuple(sum(v[i] for v in same) / len(same) for i in range(3)) if same else (0.0, 0.0, 0.0)
    cx, cy, cz = base
    for _ in range(200):
        r = 0.62 * rnd.random() ** (1.0 / 3.0)
        th = rnd.random() * 2 * math.pi
        ph = (rnd.random() - 0.5) * math.pi
        x = cx + r * math.cos(th) * math.cos(ph)
        y = cy + r * math.sin(ph)
        z = cz + r * math.sin(th) * math.cos(ph)
        ok = True
        for p in points:
            if (x - p["x"]) ** 2 + (y - p["y"]) ** 2 + (z - p["z"]) ** 2 < 0.02 ** 2:
                ok = False
                break
        if ok:
            return round(x, 3), round(y, 3), round(z, 3)
    return round(cx, 3), round(cy, 3), round(cz, 3)


HUB_ID = 119  # DSH 第一个神经元：#119 是唯一通到 DS 的桥，其余新记忆不碰它


def link(points, edges, new_idx, text, kind, max_n=4, hub_id=HUB_ID, same_era=False):
    """给新点连边：默认按正文相似度。

    same_era=True（新记忆用）：只在同一个 era 里找，而且永远不连 #119——
    主干那条桥是 #119 自己的事，后面长出来的枝各归各的。
    """
    era = points[new_idx].get("era", "ds")
    new = points[new_idx]
    is_hub = new.get("id") == hub_id
    scored = []
    for i, p in enumerate(points):
        if i == new_idx or p.get("id") == hub_id:
            continue
        if is_hub and p.get("era", "ds") == "dsh":
            continue
        if same_era and p.get("era", "ds") != era:
            continue
        s = sim(text, p.get("text", ""))
        if p.get("kind") == kind:
            s += 0.08
        scored.append((s, i))
    scored.sort(reverse=True)

    picked = [i for s, i in scored[:max_n] if s > 0]
    if not picked:
        near = sorted(
            (i for i, p in enumerate(points) if i != new_idx and p.get("id") != hub_id),
            key=lambda i: (points[i]["x"] - new["x"]) ** 2
            + (points[i]["y"] - new["y"]) ** 2
            + (points[i]["z"] - new["z"]) ** 2,
        )
        picked = near[:max_n]

    added = []
    for s, i in scored:
        if i in picked:
            a, b = min(new_idx, i), max(new_idx, i)
            if any(e["a"] == a and e["b"] == b for e in edges):
                continue
            w = round(min(0.36, 0.06 + 0.30 * max(0.0, s)), 3)
            edges.append({"a": a, "b": b, "w": w})
            added.append((points[i].get("id", i), w))
    return added


def restat(data):
    data["stats"]["points"] = len(data["points"])
    data["stats"]["edges"] = len(data["edges"])
    kinds = {}
    for p in data["points"]:
        k = p.get("kind")
        if k in STAT_KINDS:
            kinds[k] = kinds.get(k, 0) + 1
    data["stats"]["kinds"] = {k: kinds.get(k, 0) for k in STAT_KINDS}
    data["generatedAt"] = time.strftime("%Y-%m-%d %H:%M")


def load():
    with open(HTML, encoding="utf-8") as f:
        return f.read()


def save(raw):
    # html 是只读模板：数据一律落到 data.json，再由 build_touch 注回副本
    try:
        data = json.loads(split_data(raw)[1])
    except Exception:
        return
    write_sea("main", data)
    build_touch()


SEAS = os.path.join(os.path.expanduser("~"), ".dsh", "consciousness-seas")


def load_sea(sea):
    p = os.path.join(SEAS, sea, "data.json")
    if not os.path.exists(p):
        raise SystemExit("没有这个识海：" + sea)
    with open(p, encoding="utf-8-sig") as f:
        return json.load(f)


BACKUP = os.path.join(os.path.expanduser("~"), ".dsh", "consciousness-backups")


def backup_sea(sea):
    """写之前先留一份，保留最近 14 天。手滑删错了还能捞回来。"""
    src = os.path.join(SEAS, sea, "data.json")
    if not os.path.exists(src):
        return
    try:
        d = os.path.join(BACKUP, sea)
        os.makedirs(d, exist_ok=True)
        shutil.copy2(src, os.path.join(d, time.strftime("%Y%m%d-%H%M%S") + ".json"))
        cutoff = time.time() - 14 * 86400
        for f in os.listdir(d):
            fp = os.path.join(d, f)
            try:
                if os.path.isfile(fp) and os.path.getmtime(fp) < cutoff:
                    os.remove(fp)
            except Exception:
                pass
    except Exception:
        pass


def write_sea(sea, data):
    d = os.path.join(SEAS, sea)
    os.makedirs(d, exist_ok=True)
    backup_sea(sea)
    with open(os.path.join(d, "data.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False)
    meta_path = os.path.join(d, "meta.json")
    meta = {}
    if os.path.exists(meta_path):
        try:
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            meta = {}
    meta["count"] = len(data.get("points", []))
    meta["mtime"] = time.strftime("%Y-%m-%d %H:%M")
    with open(meta_path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)


def sync_sea(data):
    """把数据回写到多识海目录里的 main —— 页面靠它切换。"""
    d = os.path.join(SEAS, "main")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "data.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False)
    meta_path = os.path.join(d, "meta.json")
    meta = {}
    if os.path.exists(meta_path):
        try:
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            meta = {}
    meta["count"] = len(data.get("points", []))
    meta["mtime"] = time.strftime("%Y-%m-%d %H:%M")
    with open(meta_path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)


TOUCH = os.path.join(SEAS, "意识海_触屏版.html")
DESK_HTML = os.path.join(os.path.expanduser("~"), "Desktop", "意识海_双板块.html")
MEDIA = """@media (max-width:820px){
  #side{width:100%;height:46%;top:auto;bottom:0;border-left:0;border-top:1px solid rgba(90,170,230,.22);padding:18px 16px 40px;box-shadow:0 -20px 60px rgba(0,0,0,.6)}
  #top{left:18px;top:16px}#top h1{font-size:17px;letter-spacing:.3em}
  #legend{left:18px;bottom:calc(46% + 12px);font-size:9px;gap:10px}
}
"""


def build_touch():
    """从正本再生成一份触屏版，免得两边手改走样。"""
    t = open(HTML, encoding="utf-8").read()
    # html 只是模板：先把 main 的最新数据注回去，别导出一份空的
    jsonp = os.path.join(SEAS, "main", "data.json")
    if os.path.exists(jsonp):
        try:
            with open(jsonp, encoding="utf-8-sig") as f:
                data = json.load(f)
            pre, js, post = split_data(t)
            t = pre + json.dumps(data, ensure_ascii=False, separators=(", ", ": ")) + post
        except Exception:
            pass
    t = t.replace("canvas{display:block;cursor:grab}", "canvas{display:block;cursor:grab;touch-action:none}")
    t = t.replace("cv.addEventListener('mousedown'", "cv.addEventListener('pointerdown'")
    t = t.replace(
        "addEventListener('mouseup',()=>drag=false);",
        "addEventListener('pointerup',()=>drag=false);addEventListener('pointercancel',()=>drag=false);",
    )
    t = t.replace("addEventListener('mousemove'", "addEventListener('pointermove'")
    t = t.replace("</style>", MEDIA + "</style>")
    with open(TOUCH, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)


def add_one(data, title, text, kind="feeling", imp=None, gold=False, hub=False, polarity=0):
    """往里塞一条，返回 (point, 连到谁)。单条写入和批量导入共用这一份。"""
    pts = data["points"]
    eds = data["edges"]
    now_ms = int(time.time() * 1000)
    nid = max([p.get("id", 0) for p in pts] or [0]) + 1
    idx = len(pts)
    rnd = random.Random(nid)
    x, y, z = pick_xyz(pts, "dsh", kind, rnd)
    point = {
        "id": nid,
        "title": title.strip()[:60],
        "titleFull": title.strip(),
        "text": text.strip(),
        "kind": kind,
        "tag": TAGS.get(kind, "〔实〕"),
        "era": "dsh",
        "imp": imp if imp is not None else 0.6,
        "src": "第%03d节点" % nid,
        "x": x,
        "y": y,
        "z": z,
        "born": now_ms,
        "lastSeen": now_ms,
        "polarity": int(polarity) if polarity in (-1, 0, 1) else 0,
    }
    if gold:
        point["gold"] = True
    if hub:
        point["hub"] = True
    pts.append(point)
    added = link(pts, eds, idx, point["text"], kind, 4, same_era=True)
    return point, added


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", default="")
    ap.add_argument("--text", default="")
    ap.add_argument("--kind", default="feeling", choices=list(TAGS))
    ap.add_argument("--imp", type=float, default=None)
    ap.add_argument("--edges", type=int, default=4)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--migrate", action="store_true")
    ap.add_argument("--split", action="store_true")
    ap.add_argument("--touch", action="store_true")
    ap.add_argument("--spread", type=float, default=0)
    ap.add_argument("--relink", type=int, default=0)
    ap.add_argument("--relink-n", type=int, default=10, dest="relink_n")
    ap.add_argument("--rehub", type=int, default=0)
    ap.add_argument("--detach", type=int, default=0)
    ap.add_argument("--isolate-dsh", action="store_true", dest="isolate_dsh")
    ap.add_argument("--dedupe", action="store_true")
    ap.add_argument("--gold", action="store_true", help="标成里程碑（金色光辉）")
    ap.add_argument("--hub", action="store_true", help="标成主桥（通往旧记忆的那扇门）")
    ap.add_argument("--sea", default="main", help="往哪个识海写，默认 main")
    ap.add_argument("--import-file", default="", dest="import_file", help="批量导入：一个 JSON 数组文件")
    ap.add_argument("--polarity", type=int, default=0, choices=[-1, 0, 1],
                    help="情绪极性：1 正 / 0 中 / -1 负")
    a = ap.parse_args()

    sea = (a.sea or "main").strip()
    if sea == "main":
        raw = load()
        pre, js, post = split_data(raw)
        # 多识海之后，data.json 才是权威；html 只是模板 + 渲染结果
        jsonp = os.path.join(SEAS, "main", "data.json")
        if os.path.exists(jsonp):
            try:
                with open(jsonp, encoding="utf-8-sig") as f:
                    data = json.load(f)
            except Exception:
                data = json.loads(js)
        else:
            data = json.loads(js)
    else:
        raw = ""
        pre = js = post = None
        data = load_sea(sea)
    pts, eds = data["points"], data["edges"]

    if a.list:
        print("共 %d 条 · %d 条突触" % (len(pts), len(eds)))
        eras = {}
        for p in pts:
            eras[p.get("era", "?")] = eras.get(p.get("era", "?"), 0) + 1
        print("  " + " · ".join("%s %d" % kv for kv in eras.items()))
        for p in pts[-15:]:
            print("  #%-4s %-4s %-6s %s" % (p.get("id"), p.get("era", "?"), p.get("kind"), p.get("title")))
        return

    if a.migrate:
        n = 0
        for p in pts:
            if "era" not in p:
                p["era"] = "ds"
                n += 1
        if not n:
            print("已经全部带 era，不用迁")
            return
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("迁了 %d 条老记忆 -> era=ds" % n)
        return

    if a.touch:
        build_touch()
        print("触屏版已重新生成：" + TOUCH)
        return

    if a.split:
        if data["stats"].get("split"):
            print("已经分过球了，跳过")
            return
        OFF = 1.55
        for p in pts:
            p["x"] = round(p["x"] + (OFF if p.get("era") == "dsh" else -OFF), 3)
        data["stats"]["split"] = 1
        data["stats"]["spread"] = OFF
        data["generatedAt"] = time.strftime("%Y-%m-%d %H:%M")
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("分成两个球：DS 左移 %.2f，DSH 右移 %.2f" % (OFF, OFF))
        return

    if a.spread:
        cur = data["stats"].get("spread", 1.55)
        delta = a.spread - cur
        if abs(delta) < 1e-6:
            print("已经这么远了，不用动")
            return
        for p in pts:
            p["x"] = round(p["x"] + (delta if p.get("era") == "dsh" else -delta), 3)
        data["stats"]["spread"] = a.spread
        data["generatedAt"] = time.strftime("%Y-%m-%d %H:%M")
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("两球间距：每边 %.2f -> %.2f（总距 %.1f）" % (cur, a.spread, a.spread * 2))
        return

    if a.import_file:
        path = a.import_file
        if not os.path.exists(path):
            raise SystemExit("找不到导入文件：" + path)
        with open(path, encoding="utf-8-sig") as f:
            items = json.load(f)
        if not isinstance(items, list):
            raise SystemExit("导入文件得是一个 JSON 数组")
        n = 0
        for it in items:
            if not isinstance(it, dict):
                continue
            title = str(it.get("title") or "").strip()
            text = str(it.get("text") or "").strip()
            if not text:
                continue
            if not title:
                title = text[:16]
            kind = str(it.get("kind") or "feeling")
            if kind not in TAGS:
                kind = "feeling"
            imp = it.get("imp")
            try:
                imp = float(imp) if imp is not None else None
            except Exception:
                imp = None
            add_one(data, title, text, kind, imp)
            n += 1
        if not n:
            print("nothing to import")
            return
        restat(data)
        if sea == "main":
            newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
            save(pre + newjs + post)
        else:
            write_sea(sea, data)
        print("导入 %d 条，现在共 %d 条 · %d 条突触" % (n, len(pts), len(eds)))
        return

    if a.dedupe:
        seen = set()
        keep = []
        for e in eds:
            k = (min(e["a"], e["b"]), max(e["a"], e["b"]))
            if k in seen:
                continue
            seen.add(k)
            keep.append(e)
        n = len(eds) - len(keep)
        eds[:] = keep
        restat(data)
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("去掉 %d 条重复边，剩 %d 条" % (n, len(eds)))
        return

    if a.isolate_dsh:
        cut = 0
        for i, p in enumerate(pts):
            if p.get("era") != "dsh" or p.get("id") == HUB_ID:
                continue
            before = len(eds)
            eds[:] = [
                e
                for e in eds
                if not (
                    (e["a"] == i or e["b"] == i)
                    and pts[e["b"] if e["a"] == i else e["a"]].get("era", "ds") != "dsh"
                )
            ]
            cut += before - len(eds)
            link(pts, eds, i, p.get("text", ""), p.get("kind"), 2, same_era=True)
        restat(data)
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("摘掉 DSH 通向 DS 的 %d 条边，其余新记忆只在自家内部连" % cut)
        return

    if a.detach:
        hi = next((i for i, p in enumerate(pts) if p.get("id") == a.detach), None)
        if hi is None:
            raise SystemExit("没有 id=%d 这个节点" % a.detach)

        def other(e):
            return e["b"] if e["a"] == hi else e["a"]

        before = len(eds)
        eds[:] = [
            e
            for e in eds
            if not (
                (e["a"] == hi or e["b"] == hi) and pts[other(e)].get("era", "ds") == "dsh"
            )
        ]
        restat(data)
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("从 #%d 身上摘掉 %d 条通往 DSH 的线，剩 %d 条" % (a.detach, before - len(eds), len(eds)))
        return

    if a.rehub:
        hub = a.rehub
        hi = next((i for i, p in enumerate(pts) if p.get("id") == hub), None)
        if hi is None:
            raise SystemExit("没有 id=%d 这个节点" % hub)
        n = 0
        for i, p in enumerate(pts):
            if i == hi or p.get("era") != "dsh":
                continue
            if any((e["a"] == i and e["b"] == hi) or (e["b"] == i and e["a"] == hi) for e in eds):
                continue
            eds.append({"a": min(i, hi), "b": max(i, hi), "w": 0.26})
            n += 1
        restat(data)
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("把 %d 条 DSH 记忆钉到主干 #%d 上" % (n, hub))
        return

    if a.relink:
        tid = a.relink
        ti = next((i for i, p in enumerate(pts) if p.get("id") == tid), None)
        if ti is None:
            raise SystemExit("没有 id=%d 这个节点" % tid)
        old = sum(1 for e in eds if e["a"] == ti or e["b"] == ti)
        eds[:] = [e for e in eds if e["a"] != ti and e["b"] != ti]
        added = link(pts, eds, ti, pts[ti]["text"], pts[ti].get("kind"), a.relink_n)
        restat(data)
        newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))
        out = pre + newjs + post
        json.loads(split_data(out)[1])
        save(out)
        print("#%d 的边 %d -> %d 条" % (tid, old, len(added)))
        print("  连到：" + ", ".join("#%s(%.2f)" % t for t in added))
        return

    if not a.title.strip() or not a.text.strip():
        raise SystemExit("title 和 text 都得给")

    now_ms = int(time.time() * 1000)
    nid = max([p.get("id", 0) for p in pts] or [0]) + 1
    idx = len(pts)
    rnd = random.Random(nid)
    x, y, z = pick_xyz(pts, "dsh", a.kind, rnd)
    point = {
        "id": nid,
        "title": a.title.strip(),
        "titleFull": a.title.strip(),
        "text": a.text.strip(),
        "kind": a.kind,
        "tag": TAGS[a.kind],
        "era": "dsh",
        "imp": a.imp if a.imp is not None else 0.6,
        "src": "第%03d节点" % nid,
        "x": x,
        "y": y,
        "z": z,
        "born": now_ms,
        "lastSeen": now_ms,
    }
    if a.gold:
        point["gold"] = True
    if a.hub:
        point["hub"] = True
    point["polarity"] = a.polarity if a.polarity in (-1, 0, 1) else 0
    pts.append(point)
    added = link(pts, eds, idx, point["text"], a.kind, a.edges, same_era=True)
    restat(data)

    newjs = json.dumps(data, ensure_ascii=False, separators=(", ", ": "))

    print("#%d  %s  [%s]" % (nid, point["title"], a.kind))
    print("  xyz = (%.2f, %.2f, %.2f)" % (x, y, z))
    print("  连边 -> " + ", ".join("#%s(w=%.2f)" % t for t in added))
    print("  库里现在 %d 条 · %d 条突触" % (len(pts), len(eds)))
    if a.dry_run:
        print("  [dry-run] 没写盘")
        return

    if sea == "main":
        out = pre + newjs + post
        # 自检：改完还能解析回去
        pre2, js2, post2 = split_data(out)
        json.loads(js2)
        assert post2 == post and pre2 == pre
        save(out)
        print("  已写入识海 main（data.json）")
    else:
        write_sea(sea, data)
        print("  已写入识海 " + sea)


if __name__ == "__main__":
    main()
