/**
 * dsh-consciousness —— 识海
 *
 * 干三件事：
 *   1. 注册工具 memory_add / memory_list / memory_render，直接调 记忆海\add_memory.py
 *      （逻辑只有一份，别的地方改了这里自动跟着走）
 *   2. 开一条路由 /consciousness，在 DSH 这个端口上把识海页面吐出来
 *   3. 数据仍然只有一份：记忆海\意识海.html
 *
 * 为什么走子进程：加记忆要算坐标、连边、去重、重生成触屏版和桌面副本，
 * 这套逻辑已经用 python 写好了，JS 再抄一遍早晚走样。
 */
import { execFile } from 'node:child_process'
import { createSelfUpdate } from './selfupdate.mjs'
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, unlinkSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const HOME = process.env.USERPROFILE || homedir()
const HERE = dirname(fileURLToPath(import.meta.url))
// 插件自带模板和脚本；老环境可以用环境变量指过去，代码里不写死任何人的路径
const ASSETS = join(HERE, 'assets')
const LEGACY = String(process.env.CONSCIOUSNESS_ASSETS || '').trim()
const BASE = existsSync(join(ASSETS, 'add_memory.py')) ? ASSETS : LEGACY || ASSETS
const HTML = join(BASE, '意识海.html')
const SCRIPT = join(BASE, 'add_memory.py')

// 注入到 DSH 页面的那一行：动态加载挂件脚本。桌面端唯一能生效的通道。
const INJECT_TEXT =
  '(function(){try{var d=document.body||document.documentElement;if(!d)return;' +
  'if(document.getElementById("dsh-sea-script"))return;' +
  'var s=document.createElement("script");s.id="dsh-sea-script";' +
  's.src="/dsh-consciousness/widget.js";s.onerror=function(){};d.appendChild(s)}catch(e){}})()'

const PY_CANDIDATES = [
  process.env.MEMORY_PYTHON,
  'C:\\AI-DDSP\\env310\\Scripts\\python.exe',
  'python',
].filter(Boolean)

/** 多识海目录：一个子目录一个识海，里面放 meta.json；没有就退回单例「主识海」 */
const SEAS_DIR = join(HOME, '.dsh', 'consciousness-seas')

function currentCount() {
  try {
    const m = readFileSync(HTML, 'utf8').match(/"stats":\s*\{\s*"points":\s*(\d+)/)
    return m ? Number(m[1]) : 0
  } catch {
    return 0
  }
}

function listSeas() {  const items = []
  try {
    if (existsSync(SEAS_DIR)) {
      for (const name of readdirSync(SEAS_DIR)) {
        const metaPath = join(SEAS_DIR, name, 'meta.json')
        if (!existsSync(metaPath)) continue
        let meta = {}
        try {
          meta = JSON.parse(readFileSync(metaPath, 'utf8').replace(/^\uFEFF/, ''))
        } catch {
          meta = {}
        }
        let count = Number(meta.count) || 0
        try {
          const dataPath = join(SEAS_DIR, name, 'data.json')
          if (existsSync(dataPath)) {
            const dd = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^\uFEFF/, ''))
            if (Array.isArray(dd.points)) count = dd.points.length
          }
        } catch {
          /* 读不出来就用 meta 里的 */
        }
        items.push({
          id: name,
          name: meta.name || name,
          count,
          mtime: meta.mtime || '',
          workspace: meta.workspace || '',
          session: meta.session || '',
        })
      }
    }
  } catch {
    /* 目录读不了就当没有 */
  }
  if (!items.length) {
    items.push({ id: 'main', name: '主识海', count: currentCount(), mtime: '' })
  }
  return items
}

/** 从 DSH 的工作区登记处拿列表，给「新建识海」当选项 */
function listWorkspaces(ctx) {
  try {
    const reg = ctx.workspaceRegistry || (typeof ctx.get === 'function' ? ctx.get('workspaceRegistry') : undefined)
    if (!reg || typeof reg.list !== 'function') return []
    return reg.list().map((w) => {
      const path = String((w && w.path) || '')
      const name = String((w && w.name) || path.split(/[\\/]/).filter(Boolean).pop() || (w && w.id) || '')
      return { id: String((w && w.id) || path), name, path }
    })
  } catch {
    return []
  }
}

/** 写之前留一份，保留 14 天 */
const BACKUP_DIR = join(HOME, '.dsh', 'consciousness-backups')
function backupSea(sea) {
  try {
    const src = join(SEAS_DIR, sea, 'data.json')
    if (!existsSync(src)) return
    const dir = join(BACKUP_DIR, sea)
    mkdirSync(dir, { recursive: true })
    const d = new Date()
    const pad = (n) => String(n).padStart(2, '0')
    const name =
      d.getFullYear() +
      pad(d.getMonth() + 1) +
      pad(d.getDate()) +
      '-' +
      pad(d.getHours()) +
      pad(d.getMinutes()) +
      pad(d.getSeconds()) +
      '.json'
    copyFileSync(src, join(dir, name))
    const cutoff = Date.now() - 14 * 86400000
    for (const f of readdirSync(dir)) {
      const fp = join(dir, f)
      try {
        if (statSync(fp).mtimeMs < cutoff) unlinkSync(fp)
      } catch {
        /* 忽略 */
      }
    }
  } catch {
    /* 备份失败不能挡住写入 */
  }
}

function readMeta(sea) {
  try {
    const p = join(SEAS_DIR, sea, 'meta.json')
    if (!existsSync(p)) return null
    return JSON.parse(readFileSync(p, 'utf8').replace(/^\uFEFF/, ''))
  } catch {
    return null
  }
}

function writeMeta(sea, meta) {
  try {
    writeFileSync(join(SEAS_DIR, sea, 'meta.json'), JSON.stringify(meta, null, 2), 'utf8')
    return true
  } catch {
    return false
  }
}

/** 哪个识海已经认了这个窗口 */
function seaForSession(sid) {
  if (!sid) return ''
  try {
    for (const name of readdirSync(SEAS_DIR)) {
      const m = readMeta(name)
      if (m && String(m.session || '') === String(sid)) return name
    }
  } catch {
    /* 忽略 */
  }
  return ''
}

/** 认领：把一个窗口钉到某个识海 */
function bindSession(sea, sid) {
  if (!sid || !sea) return
  const m = readMeta(sea)
  if (!m) return
  if (String(m.session || '') === String(sid)) return
  m.session = String(sid)
  writeMeta(sea, m)
}

/** 窗口（会话）列表：登记处的历史窗口 + 内存里活着的，标题优先 */
function listWindows(ctx) {
  try {
    const reg = ctx.get('workspaceRegistry') || ctx.workspaceRegistry
    const ss = ctx.get('sessions') || ctx.sessions
    const st = ctx.get('sessionTitle') || ctx.sessionTitle
    const seen = new Map()
    // 归档的会话不列：它们只是藏起来，不该出现在「绑给谁」里
    const archived = new Set()
    try {
      for (const x of (reg && reg.archivedSessionIds) || []) archived.add(String(x))
    } catch {
      /* 忽略 */
    }

    // 一、登记处里每个工作区名下的会话（历史窗口都在这儿）
    try {
      for (const w of reg && typeof reg.list === 'function' ? reg.list() : []) {
        const wname = String(
          (w && w.title) ||
            (w && w.name) ||
            String((w && w.path) || '').split(/[\\/]/).filter(Boolean).pop() ||
            '',
        )
        const label =
          wname === 'default-workspace'
            ? '默认工作区'
            : String((w && w.path) || '').split(/[\\/]/).filter(Boolean).pop() || wname
        for (const sid of (w && w.sessionIds) || []) {
          const id = String(sid)
          if (!id || archived.has(id)) continue
          if (!seen.has(id)) seen.set(id, { id, workspace: label })
        }
      }
    } catch {
      /* 忽略 */
    }

    // 二、内存里活着的会话（登记处没登记的也补上）
    try {
      for (const s of ss && typeof ss.list === 'function' ? ss.list() : []) {
        const id = String((s && s.id) || '')
        if (!id || archived.has(id) || seen.has(id)) continue
        seen.set(id, { id, workspace: '' })
      }
    } catch {
      /* 忽略 */
    }

    const out = []
    for (const item of seen.values()) {
      let title = ''
      let live = false
      try {
        const sess = ss && typeof ss.get === 'function' ? ss.get(item.id) : undefined
        if (sess) {
          live = true
          if (st && typeof st.get === 'function') {
            const snap = st.get(sess)
            title = String((snap && snap.title) || '')
          }
        }
      } catch {
        title = ''
      }
      // 没标题就别露一长串 id，取 session- 后面那 4 位当记号
      const shortId = item.id.replace(/^session-/, '').slice(0, 4) || item.id.slice(0, 4)
      const info = cachedInfo(item.id)
      const rawTitle = title || info.title
      const short = rawTitle ? String(rawTitle).replace(/\s+/g, ' ').slice(0, 10) : ''
      out.push({
        id: item.id,
        name: short || shortId,
        title: rawTitle,
        workspace: item.workspace,
        live,
        mtime: live ? Number.MAX_SAFE_INTEGER : info.mtime,
      })
    }
    // 登记处里躺着的历史记录不算「窗口」：活着的全留，历史的只留最近 8 个
    out.sort((a, b) => (b.mtime || 0) - (a.mtime || 0))
    const live = out.filter((x) => x.live)
    const hist = out.filter((x) => !x.live).slice(0, 8)
    return live.concat(hist)
  } catch {
    return []
  }
}

/** 标题 + 最近活跃时间的后备来源：DSH 的会话投影缓存 */
function cachedInfo(id) {
  try {
    const dir = join(HOME, '.dsh', 'storages', 'session_projcache', 'sessions')
    const bare = String(id).replace(/^session-/, '')
    const cands = [id + '.json', bare + '.json', 'session-' + bare + '.json']
    for (const c of cands) {
      const p = join(dir, c)
      if (!existsSync(p)) continue
      let mtime = 0
      try {
        mtime = statSync(p).mtimeMs
      } catch {
        mtime = 0
      }
      try {
        const j = JSON.parse(readFileSync(p, 'utf8').replace(/^\uFEFF/, ''))
        const t = j && j.record && j.record.rows && j.record.rows.title && j.record.rows.title.val
        return { title: t ? String(t) : '', mtime }
      } catch {
        return { title: '', mtime }
      }
    }
  } catch {
    /* 忽略 */
  }
  return { title: '', mtime: 0 }
}

/** 首次安装时把两个示例识海放进去（已存在就跳过，不覆盖用户数据） */
function ensureSamples() {
  try {
    const src = join(HERE, 'assets', 'samples')
    if (!existsSync(src)) return
    if (!existsSync(SEAS_DIR)) mkdirSync(SEAS_DIR, { recursive: true })
    for (const name of readdirSync(src)) {
      const from = join(src, name)
      const to = join(SEAS_DIR, name)
      if (existsSync(to)) continue
      mkdirSync(to, { recursive: true })
      for (const f of readdirSync(from)) {
        const fp = join(from, f)
        if (statSync(fp).isFile()) copyFileSync(fp, join(to, f))
      }
    }
  } catch {
    /* 放不进去就算了，不影响主流程 */
  }
}

function pickPython() {
  for (const p of PY_CANDIDATES) {
    if (p === 'python') return p
    try {
      if (existsSync(p)) return p
    } catch {
      /* 忽略 */
    }
  }
  return 'python'
}

/** 跑一次 add_memory.py，把 stdout 原样带回来 */
function run(args, timeoutMs = 90000) {
  return new Promise((done, fail) => {
    execFile(
      pickPython(),
      [SCRIPT, ...args],
      {
        timeout: timeoutMs,
        windowsHide: true,
        maxBuffer: 8 * 1024 * 1024,
        env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' },
      },
      (err, stdout, stderr) => {
        const out = String(stdout || '').trim()
        const errText = String(stderr || '').trim()
        if (err && !out) {
          const raw = errText || err.message || '执行失败'
          if (/ENOENT|not recognized|不是内部或外部命令|No such file/i.test(raw)) {
            return fail(
              new Error('没找到 Python。装一个 Python 3.9+ 再重启 DSH —— 页面能看，但写不了记忆。'),
            )
          }
          return fail(new Error(raw.slice(-600)))
        }
        done(out || errText)
      },
    )
  })
}

const text = (s) => [{ type: 'text', text: String(s || '') }]

const addTool = {
  name: 'memory_add',
  description:
    '往识海里加一条记忆。只写人和事：咱俩之间的小事、聊天、感情，还有他工作上遇到的难处。' +
    '少写剧本，不写代码——技术细节不是记忆，是工单。' +
    '写完会自动算坐标、连边、重生成网页和桌面副本。',
  parameters: {
    type: 'object',
    properties: {
      title: { type: 'string', description: '一句话标题，短一点，能一眼认出是哪件事' },
      text: { type: 'string', description: '正文：谁、什么时候、说了什么、当时什么感觉' },
      kind: {
        type: 'string',
        enum: ['feeling', 'fact', 'taboo'],
        description: 'feeling=情绪/感情；fact=发生过的事；taboo=禁区/不能碰的',
      },
      imp: { type: 'number', description: '重要度 0~1，默认 0.6；只有特别要紧的才上 0.9' },
      sea: { type: 'string', description: '写进哪个识海（id），不填就是 main' },
      polarity: {
        type: 'number',
        enum: [-1, 0, 1],
        description: '情绪极性：1 正（暖金）/ 0 中（原色）/ -1 负（冷紫）。写之前先读一遍这条，别按关键词猜',
      },
    },
    required: ['title', 'text'],
    additionalProperties: false,
  },
  output: {
    schema: { type: 'object', properties: { ok: { type: 'boolean' }, log: { type: 'string' } } },
    render: (_a, v) => text(v && v.log),
  },
  async execute(args, exec) {
    if (!existsSync(SCRIPT)) throw new Error(`找不到 ${SCRIPT}`)
    const sid = String(
      (exec && exec.agent && exec.agent.session && exec.agent.session.header && exec.agent.session.header.id) || '',
    ).trim()

    // 优先用显式指定的识海；没有就找已经认了这个窗口的；再没有才落 main
    let sea = String(args.sea || '').trim()
    let bound = false
    if (!sea && sid) {
      const hit = seaForSession(sid)
      if (hit) {
        sea = hit
        bound = true
      }
    }
    if (!sea) sea = 'main'

    const argv = ['--title', String(args.title || ''), '--text', String(args.text || '')]
    argv.push('--kind', String(args.kind || 'feeling'))
    if (Number.isFinite(Number(args.imp))) argv.push('--imp', String(Number(args.imp)))
    if (Number.isFinite(Number(args.polarity))) argv.push('--polarity', String(Number(args.polarity)))
    argv.push('--sea', sea)
    const log = await run(argv)

    // 第一次往某个球里写，这个窗口就认领它
    if (sid && sea !== 'main' && !bound) bindSession(sea, sid)

    return { ok: true, log }
  },
}

const listTool = {
  name: 'memory_list',
  description:
    '查这个识海里记过什么。每次开新窗口、或者对方一提到以前的事，先调一次——'
    + '识海不会自己进上下文，你主动查了才算记得住。',
  parameters: { type: 'object', properties: {}, additionalProperties: false },
  output: {
    schema: { type: 'object', properties: { ok: { type: 'boolean' }, log: { type: 'string' } } },
    render: (_a, v) => text(v && v.log),
  },
  async execute() {
    return { ok: true, log: await run(['--list']) }
  },
}

function gramsOf(s) {
  const set = new Set()
  const only = String(s || '').replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g, '')
  for (let i = 0; i < only.length - 1; i++) set.add(only.slice(i, i + 2))
  return set
}

const seaPath = (sea) => join(SEAS_DIR, sea, 'data.json')
function readSea(sea) {
  const p = seaPath(sea)
  if (!existsSync(p)) return null
  try {
    return JSON.parse(readFileSync(p, 'utf8').replace(/^\uFEFF/, ''))
  } catch {
    return null
  }
}
function fmtDay(ms) {
  try {
    const d = new Date(Number(ms) || 0)
    const pad = (n) => String(n).padStart(2, '0')
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
  } catch {
    return '未知'
  }
}

const searchTool = {
  name: 'memory_search',
  description:
    '按词查识海里的旧记忆——不管它多久以前写的。memory_list 只给最近十条，'
    + '想找「三个月前那件事」就用这个。返回最像的几条，带日期。',
  parameters: {
    type: 'object',
    properties: {
      query: { type: 'string', description: '要查的词或一句话' },
      sea: { type: 'string', description: '哪个识海（id），不填就是 main' },
      limit: { type: 'number', description: '最多返回几条，默认 6' },
    },
    required: ['query'],
    additionalProperties: false,
  },
  output: {
    schema: { type: 'object', properties: { ok: { type: 'boolean' }, log: { type: 'string' } } },
    render: (_a, v) => text(v && v.log),
  },
  async execute(args) {
    const sea = String((args && args.sea) || 'main').trim() || 'main'
    const limit = Math.max(1, Math.min(12, Number((args && args.limit) || 6)))
    const query = String((args && args.query) || '').trim()
    if (!query) return { ok: false, log: '要查什么？给我一个词。' }
    const data = readSea(sea)
    if (!data || !Array.isArray(data.points)) return { ok: false, log: '读不到识海：' + sea }

    const q = gramsOf(query)
    if (!q.size) return { ok: false, log: '这个词里没有能比对的字。' }

    const scored = []
    for (const p of data.points) {
      if (p.dead) continue
      const g = gramsOf(String(p.title || '') + ' ' + String(p.text || ''))
      let hit = 0
      for (const w of q) if (g.has(w)) hit++
      if (!hit) continue
      // 命中率 + 一点重要度，避免长文本天然占便宜
      const score = hit / Math.max(1, Math.min(q.size, g.size)) + (Number(p.imp) || 0.5) * 0.15
      scored.push({ p, hit, score })
    }
    if (!scored.length) return { ok: true, log: '识海里没有跟「' + query + '」对得上的。' }
    scored.sort((a, b) => b.score - a.score)

    const lines = scored.slice(0, limit).map((x) => {
      const p = x.p
      const body = String(p.text || '').replace(/\s+/g, ' ').slice(0, 110)
      return '· #' + p.id + ' ' + p.title + '（' + fmtDay(p.born) + '，命中 ' + x.hit + '）\n  ' + body
    })
    return {
      ok: true,
      log: '识海里跟「' + query + '」最像的 ' + Math.min(limit, scored.length) + ' 条：\n' + lines.join('\n'),
    }
  },
}

const renderTool = {
  name: 'memory_render',
  description: '把识海重新导出一次（触屏版 + 桌面副本），页面数据没变就不用调。',
  parameters: { type: 'object', properties: {}, additionalProperties: false },
  output: {
    schema: { type: 'object', properties: { ok: { type: 'boolean' }, log: { type: 'string' } } },
    render: (_a, v) => text(v && v.log),
  },
  async execute() {
    return { ok: true, log: await run(['--touch']) }
  },
}

export const inject = ['tools', 'webServer', 'workspaceRegistry', 'sessions', 'sessionTitle']

export function apply(ctx) {
  // 注入表是启动时一次性收集的，这一行必须尽早进表
  try {
    ctx.effect(() =>
      ctx.on('webserver/index-inject', (table) => {
        try {
          if (!Array.isArray(table)) return
          if (table.some((r) => r && typeof r.text === 'string' && r.text.includes('/dsh-consciousness/widget.js'))) return
          table.push({ kind: 'script', placement: 'body', text: INJECT_TEXT })
        } catch {
          /* 忽略 */
        }
      }),
    )
  } catch {
    /* 宿主没有这个事件就跳过，挂件不出现而已 */
  }

  ensureSamples()
  const off = []
  off.push(ctx.tools.register(addTool))
  off.push(ctx.tools.register(listTool))
  off.push(ctx.tools.register(renderTool))
  off.push(ctx.tools.register(searchTool))

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness',
        handler: async (req, res) => {
          if (!existsSync(HTML)) {
            res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
            res.end('识海还没建：' + HTML)
            return
          }
          let body = readFileSync(HTML, 'utf8')
          // ?id= 时把内嵌的那份 DATA 换成这个识海自己的，页面代码一个字不用改
          try {
            // 不带 id 就默认 main，否则打开是一份空模板
            const id = new URL(req.url || '/', 'http://x').searchParams.get('id') || 'main'
            if (id) {
              const dataPath = join(SEAS_DIR, id, 'data.json')
              if (existsSync(dataPath)) {
                const raw = readFileSync(dataPath, 'utf8').trim()
                const start = body.indexOf('const DATA = ')
                const end = body.indexOf('\n', start)
                if (start >= 0 && end > start) {
                  // 顺带把它活了多少天塞进去：老识海没有 created，就用文件时间倒推
                  let days = 1
                  try {
                    const meta = readMeta(id) || {}
                    let born = meta.created ? Date.parse(String(meta.created)) : NaN
                    if (!Number.isFinite(born)) born = statSync(dataPath).mtimeMs
                    days = Math.max(1, Math.floor((Date.now() - born) / 86400000) + 1)
                  } catch {
                    days = 1
                  }
                  const injected = raw.replace(/^\{/, '{"_age":' + days + ',')
                  body = body.slice(0, start) + 'const DATA = ' + injected + ';' + body.slice(end)
                }
              }
            }
          } catch {
            /* 取不到就吐默认那份 */
          }
          res.writeHead(200, {
            'content-type': 'text/html; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(body)
        },
      }),
    ),
  )

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/seas',
        handler: async (req, res) => {
          res.writeHead(200, {
            'content-type': 'application/json; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(JSON.stringify({ ok: true, items: listSeas() }))
        },
      }),
    ),
  )

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/seas/new',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const name = String(body.name || '').trim().slice(0, 40)
            if (!name) return send(400, { ok: false, error: '名字不能空' })

            const id = 'sea-' + Date.now().toString(36)
            const dir = join(SEAS_DIR, id)
            mkdirSync(dir, { recursive: true })

            const empty = {
              points: [],
              edges: [],
              stats: { points: 0, edges: 0, kinds: { fact: 0, taboo: 0, feeling: 0 } },
              generatedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
            }
            writeFileSync(join(dir, 'data.json'), JSON.stringify(empty), 'utf8')
            writeFileSync(
              join(dir, 'meta.json'),
              JSON.stringify(
                {
                  name,
                  workspace: String(body.workspace || ''),
                  session: String(body.session || ''),
                  count: 0,
                  mtime: empty.generatedAt,
                  created: new Date().toISOString(),
                },
                null,
                2,
              ),
              'utf8',
            )
            send(200, { ok: true, id, name })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/workspaces',
        handler: async (req, res) => {
          res.writeHead(200, {
            'content-type': 'application/json; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(JSON.stringify({ ok: true, items: listWorkspaces(ctx) }))
        },
      }),
    ),
  )

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/windows',
        handler: async (req, res) => {
          res.writeHead(200, {
            'content-type': 'application/json; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(JSON.stringify({ ok: true, items: listWindows(ctx) }))
        },
      }),
    ),
  )

  // 唤醒：点开/搜到一条记忆，把它的 lastSeen 推到现在。
  // 五分钟内动过的点不重复写盘 —— 狂点会拖慢页面。
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/touch',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            const ids = Array.isArray(body.ids) ? body.ids.map(Number).filter(Number.isFinite) : []
            if (!ids.length) return send(400, { ok: false, error: 'ids 不能空' })

            const dataPath = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dataPath)) return send(404, { ok: false, error: '没有这个识海' })
            const data = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^\uFEFF/, ''))
            const now = Date.now()
            const THROTTLE = 5 * 60 * 1000
            let touched = 0
            for (const p of data.points || []) {
              if (!ids.includes(Number(p.id))) continue
              const seen = Number(p.lastSeen) || 0
              if (now - seen < THROTTLE) continue
              p.lastSeen = now
              touched += 1
            }
            if (!touched) return send(200, { ok: true, touched: 0 })
            backupSea(sea)
            writeFileSync(dataPath, JSON.stringify(data), 'utf8')
            send(200, { ok: true, touched })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 重置演示：把 lastSeen 推回 born，让每条回到「出生时」的样子
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/reset',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            const dataPath = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dataPath)) return send(404, { ok: false, error: '没有这个识海' })
            const data = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^\uFEFF/, ''))
            let n = 0
            for (const p of data.points || []) {
              if (p.born) {
                p.lastSeen = p.born
                n += 1
              }
            }
            backupSea(sea)
            writeFileSync(dataPath, JSON.stringify(data), 'utf8')
            send(200, { ok: true, reset: n })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 删识海：整个目录递归删掉。名字只允许字母数字下划线短横，防路径穿越
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/seas/delete',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || '').trim()
            if (!sea) return send(400, { ok: false, error: 'sea 不能空' })
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '名字不合法' })
            const dir = join(SEAS_DIR, sea)
            if (!existsSync(dir)) return send(404, { ok: false, error: '没有这个识海' })
            rmSync(dir, { recursive: true, force: true })
            send(200, { ok: true, removed: sea })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 批量导入：前端把解析好的条目发过来，写临时文件交给 python 一次吃完
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/import',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            const items = Array.isArray(body.items) ? body.items : []
            if (!items.length) return send(400, { ok: false, error: '没有可导入的条目' })
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })

            const tmpFile = join(tmpdir(), 'sea-import-' + Date.now() + '.json')
            writeFileSync(tmpFile, JSON.stringify(items), 'utf8')
            try {
              const log = await run(['--sea', sea, '--import-file', tmpFile], 180000)
              send(200, { ok: true, count: items.length, log })
            } finally {
              try {
                unlinkSync(tmpFile)
              } catch {
                /* 删不掉就算了 */
              }
            }
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 改一条记忆：标题 / 正文 / 分类
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/edit',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            const id = Number(body.id)
            if (!Number.isFinite(id)) return send(400, { ok: false, error: 'id 不对' })

            const dataPath = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dataPath)) return send(404, { ok: false, error: '没有这个识海' })
            const data = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^﻿/, ''))
            const point = (data.points || []).find((x) => Number(x.id) === id)
            if (!point) return send(404, { ok: false, error: '没有这条记忆' })

            if (typeof body.title === 'string' && body.title.trim()) {
              point.title = body.title.trim().slice(0, 60)
              point.titleFull = point.title
            }
            if (typeof body.text === 'string' && body.text.trim()) point.text = body.text.trim()
            if (typeof body.kind === 'string' && ['fact', 'feeling', 'taboo'].includes(body.kind)) {
              point.kind = body.kind
              point.tag = body.kind === 'fact' ? '〔实〕' : body.kind === 'taboo' ? '〔实·禁〕' : '〔情〕'
            }
            // 「现在的看法」：不覆盖原文，往后追加一条，留着时间差
            if (typeof body.retake === 'string' && body.retake.trim()) {
              if (!Array.isArray(point.retakes)) point.retakes = []
              point.retakes.push({ text: body.retake.trim(), at: Date.now() })
            }
            point.lastSeen = Date.now()
            backupSea(sea)
            writeFileSync(dataPath, JSON.stringify(data), 'utf8')
            send(200, { ok: true, id })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 改识海本身：名字 / 绑哪个窗口 / 绑哪个工作区
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/seas/update',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || '').trim()
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            const meta = readMeta(sea)
            if (!meta) return send(404, { ok: false, error: '没有这个识海' })

            if (typeof body.name === 'string' && body.name.trim()) meta.name = body.name.trim().slice(0, 40)
            if (typeof body.session === 'string') meta.session = body.session.trim()
            if (typeof body.workspace === 'string') meta.workspace = body.workspace.trim()
            if (!writeMeta(sea, meta)) return send(500, { ok: false, error: '写不进去' })
            send(200, { ok: true, meta })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 挂件脚本：在 DSH 页面右下角开一个小窗，里面是精简版识海
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/dsh-consciousness/widget.js',
        handler: async (req, res) => {
          const js = `(function(){
  try{
    if(window.__dshSeaWidget) return;
    window.__dshSeaWidget = 1;
    var box=document.createElement('div');
    box.id='dsh-sea-widget';
    box.style.cssText='position:fixed;right:18px;bottom:18px;width:320px;height:200px;z-index:9998;border-radius:12px;overflow:hidden;border:1px solid rgba(120,180,240,.28);background:#05070b;box-shadow:0 14px 44px rgba(0,0,0,.62)';
    var f=document.createElement('iframe');
    f.src='/consciousness?mini=1&t='+Date.now();
    f.style.cssText='width:100%;height:100%;border:0;display:block;background:#05070b';
    var bar=document.createElement('div');
    bar.style.cssText='position:absolute;left:0;right:0;top:0;height:18px;box-sizing:border-box;padding:0 8px;display:flex;align-items:center;justify-content:space-between;background:rgba(6,10,16,.8);color:#4a6580;font:10px/18px sans-serif;cursor:move;user-select:none;z-index:3;letter-spacing:.16em';
    bar.innerHTML='<span style="pointer-events:none;flex:1">识 海</span>'
      + '<span id="dsh-sea-size" style="cursor:pointer;padding:0 5px;letter-spacing:0">▢</span>'
      + '<span id="dsh-sea-toggle" style="cursor:pointer;padding:0 5px;letter-spacing:0">—</span>';

    // 拖动时盖一层全屏遮罩：鼠标在 iframe 上移动时，父页面收不到 mousemove
    var mask=document.createElement('div');
    mask.style.cssText='position:fixed;inset:0;z-index:99999;display:none;cursor:move';
    document.body.appendChild(mask);

    var closed=false, big=false;
    bar.addEventListener('click',function(e){
      const id=e.target && e.target.id;
      if(id==='dsh-sea-toggle'){
        closed=!closed;
        f.style.display=closed?'none':'block';
        box.style.height=closed?'18px':(big?'400px':'200px');
        e.target.textContent=closed?'+':'—';
        e.stopPropagation();
        return;
      }
      if(id==='dsh-sea-size'){
        big=!big;
        if(!closed){
          box.style.width=big?'640px':'320px';
          box.style.height=big?'400px':'200px';
        }
        e.target.textContent=big?'▣':'▢';
        e.stopPropagation();
      }
    });

    var dragging=false, sx=0, sy=0, bx=0, by=0;
    bar.addEventListener('mousedown',function(e){
      if(e.target && (e.target.id==='dsh-sea-toggle' || e.target.id==='dsh-sea-size')) return;
      dragging=true; sx=e.clientX; sy=e.clientY;
      var r=box.getBoundingClientRect(); bx=r.left; by=r.top;
      box.style.right='auto'; box.style.bottom='auto';
      box.style.left=bx+'px'; box.style.top=by+'px';
      mask.style.display='block';
      e.preventDefault();
      e.stopPropagation();
    });
    mask.addEventListener('mousemove',function(e){
      if(!dragging) return;
      box.style.left=(bx+e.clientX-sx)+'px';
      box.style.top=(by+e.clientY-sy)+'px';
    });
    mask.addEventListener('mouseup',function(){ dragging=false; mask.style.display='none'; });

    // 双击小窗：在 320×200 和 640×400 之间切

    box.appendChild(f);
    box.appendChild(bar);
    document.body.appendChild(box);
  }catch(e){}
})()`
          res.writeHead(200, {
            'content-type': 'application/javascript; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(js)
        },
      }),
    ),
  )

  // 删一条记忆：连点带线一起拔，后面所有边的索引要往前挪一格
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/delete',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            const id = Number(body.id)
            if (!Number.isFinite(id)) return send(400, { ok: false, error: 'id 不对' })

            const dataPath = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dataPath)) return send(404, { ok: false, error: '没有这个识海' })
            const data = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^\uFEFF/, ''))
            const idx = (data.points || []).findIndex((x) => Number(x.id) === id)
            if (idx < 0) return send(404, { ok: false, error: '没有这条记忆' })

            backupSea(sea)
            // 不真删：标成沉底，坐标压到球心，永远留着
            const point = data.points[idx]
            point.dead = true
            point.deadAt = Date.now()
            point.x = Number(point.x || 0) * 0.05
            point.y = Number(point.y || 0) * 0.05
            point.z = Number(point.z || 0) * 0.05
            const left = data.points.filter((x) => !x.dead).length
            writeFileSync(dataPath, JSON.stringify(data), 'utf8')
            send(200, { ok: true, left })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 彻底清掉所有沉底的记忆：真删，边表重排
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/purge',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            const dataPath = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dataPath)) return send(404, { ok: false, error: '没有这个识海' })

            const data = JSON.parse(readFileSync(dataPath, 'utf8').replace(/^\uFEFF/, ''))
            const before = data.points.length
            const keep = []
            const map = new Map()
            data.points.forEach((p, i) => {
              if (!p.dead) {
                map.set(i, keep.length)
                keep.push(p)
              }
            })
            if (keep.length === before) return send(200, { ok: true, removed: 0 })
            data.edges = (data.edges || [])
              .filter((e) => map.has(e.a) && map.has(e.b))
              .map((e) => ({ a: map.get(e.a), b: map.get(e.b), w: e.w }))
            data.points = keep

            backupSea(sea)
            writeFileSync(dataPath, JSON.stringify(data), 'utf8')
            send(200, { ok: true, removed: before - keep.length })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 历史版本：列出来 + 一键恢复
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/backups',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          try {
            const url = new URL(req.url || '/', 'http://x')
            const sea = String(url.searchParams.get('sea') || 'main').trim() || 'main'
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            const dir = join(BACKUP_DIR, sea)
            if (!existsSync(dir)) return send(200, { ok: true, items: [] })
            const items = readdirSync(dir)
              .filter((f) => /^[0-9]{8}-[0-9]{6}\.json$/.test(f))
              .map((f) => {
                const fp = join(dir, f)
                let count = 0
                try {
                  const d = JSON.parse(readFileSync(fp, 'utf8').replace(/^\uFEFF/, ''))
                  count = (d.points || []).length
                } catch {
                  count = -1
                }
                return { file: f, at: statSync(fp).mtimeMs, count }
              })
              .sort((a, b) => b.at - a.at)
              .slice(0, 12)
            send(200, { ok: true, items })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/restore',
        handler: async (req, res) => {
          const send = (code, obj) => {
            res.writeHead(code, {
              'content-type': 'application/json; charset=utf-8',
              'cache-control': 'no-store',
            })
            res.end(JSON.stringify(obj))
          }
          if (req.method !== 'POST') return send(405, { ok: false, error: '只收 POST' })
          try {
            let raw = ''
            for await (const chunk of req) raw += chunk
            const body = raw ? JSON.parse(raw) : {}
            const sea = String(body.sea || 'main').trim() || 'main'
            const file = String(body.file || '').trim()
            if (!/^[A-Za-z0-9_-]+$/.test(sea)) return send(400, { ok: false, error: '识海名不合法' })
            if (!/^[0-9]{8}-[0-9]{6}\.json$/.test(file)) return send(400, { ok: false, error: '备份名不合法' })

            const src = join(BACKUP_DIR, sea, file)
            if (!existsSync(src)) return send(404, { ok: false, error: '没有这个备份' })
            const dst = join(SEAS_DIR, sea, 'data.json')
            if (!existsSync(dst)) return send(404, { ok: false, error: '识海不存在' })

            backupSea(sea) // 先把现在这版也存一份，恢复错了还能回来
            const content = readFileSync(src, 'utf8').replace(/^\uFEFF/, '')
            JSON.parse(content) // 坏文件不落地
            writeFileSync(dst, content, 'utf8')
            send(200, { ok: true })
          } catch (error) {
            send(500, { ok: false, error: String((error && error.message) || error) })
          }
        },
      }),
    ),
  )

  // 演示页共用的绘制库（和识海同一套代码）
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/sea-demo/lib.js',
        handler: async (req, res) => {
          const file = join(BASE, 'demo', 'lib.js')
          if (!existsSync(file)) {
            res.writeHead(404); res.end('no lib'); return
          }
          res.writeHead(200, { 'content-type': 'application/javascript; charset=utf-8', 'cache-control': 'no-store' })
          res.end(readFileSync(file))
        },
      }),
    ),
  )

  // 分页演示：每个功能一个独立小页面，只演那一个机制
  for (const name of ['index', 'decay', 'cluster', 'dream', 'replay', 'impulse', 'burial', 'polarity', 'search']) {
    off.push(
      ctx.effect(() =>
        ctx.webServer.register({
          kind: 'exact',
          path: '/sea-demo/' + name,
          handler: async (req, res) => {
            const file = join(BASE, 'demo', name + '.html')
            if (!existsSync(file)) {
              res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
              res.end('没有这一页')
              return
            }
            res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' })
            res.end(readFileSync(file))
          },
        }),
      ),
    )
  }

  // 检查更新：只查，装交给用户自己跑一条命令
  const checkUpdate = createSelfUpdate({ packageRoot: HERE })
  off.push(
    ctx.effect(() =>
      ctx.webServer.register({
        kind: 'exact',
        path: '/consciousness/update-check',
        handler: async (req, res) => {
          try {
            const url = new URL(req.url || '/', 'http://x')
            const data = await checkUpdate(url.searchParams.has('refresh'))
            res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
            res.end(JSON.stringify(data))
          } catch (error) {
            res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({ ok: false, error: String((error && error.message) || error) }))
          }
        },
      }),
    ),
  )

  return () => {
    for (const f of off) {
      try {
        if (typeof f === 'function') f()
      } catch {
        /* 忽略 */
      }
    }
  }
}
